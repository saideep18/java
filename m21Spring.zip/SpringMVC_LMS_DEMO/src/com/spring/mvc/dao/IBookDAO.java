package com.spring.mvc.dao;

import java.util.List;

import com.spring.mvc.exceptions.BookException;
import com.spring.mvc.model.Book;

public interface IBookDAO {

	void insertBook(Book book);

	List<Book> getAllBooks();

	Book getBookDetails(int id) throws BookException;

	void updateBookData(Book book);

}
