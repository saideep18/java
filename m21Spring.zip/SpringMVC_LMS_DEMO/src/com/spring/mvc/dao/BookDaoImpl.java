package com.spring.mvc.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.mvc.exceptions.BookException;
import com.spring.mvc.model.Book;

@Repository
public class BookDaoImpl implements IBookDAO {

	@PersistenceContext
	private EntityManager manager;

	@Override
	public void insertBook(Book book) {
		manager.persist(book);
	}

	@Override
	public List<Book> getAllBooks() {

		Query query = manager.createQuery("select b from Book b");
		List<Book> list = query.getResultList();
		return list;
	}

	@Override
	public Book getBookDetails(int id) throws BookException {
		
		Book book = null;
		try {
			book = manager.find(Book.class, id);
		}catch (Exception e) {
			throw new BookException("no book present with the given id:");
		}
		return book;
	}

	@Override
	public void updateBookData(Book book) {

		/*Book book2 = manager.find(Book.class, book.getId());
		book2.setAuthor(book.getAuthor());
		book2.setCategory(book.getCategory());
		book2.setCost(book.getCost());
		book2.setName(book.getName());
		*/
		manager.merge(book);
		
	}

}
