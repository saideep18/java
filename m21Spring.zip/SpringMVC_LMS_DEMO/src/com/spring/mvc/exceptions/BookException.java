package com.spring.mvc.exceptions;

public class BookException extends Exception {

	public BookException(String message) {
		super(message);
	}
}
