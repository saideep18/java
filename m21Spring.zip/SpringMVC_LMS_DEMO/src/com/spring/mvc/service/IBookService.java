package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.exceptions.BookException;
import com.spring.mvc.model.Book;

public interface IBookService {

	void insertBook(Book book);

	List<Book> getAllBooks();

	Book getBookDetails(int id) throws BookException;

	void updateBookData(Book book);

}
