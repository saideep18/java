package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;
import com.cg.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao = new EmployeeDaoImpl();
	@Override
	public int addEmployee(Employee bean) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.addEmployee(bean);
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getAllEmployee();
	}

	@Override
	public Employee getEmployeeById(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployeeById(empId);
	}

	@Override
	public Employee updateEmployee(int empId, int empSal)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.updateEmployee(empId, empSal);
	}
	

}
