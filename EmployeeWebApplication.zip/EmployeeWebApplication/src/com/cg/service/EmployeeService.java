package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;

public interface EmployeeService {

	public int addEmployee(Employee bean)throws EmployeeException;
	public ArrayList<Employee>getAllEmployee()throws EmployeeException;
	public Employee getEmployeeById(int empId)throws EmployeeException;
	public Employee updateEmployee(int empId,int empSal)throws EmployeeException;
}
