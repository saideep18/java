package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{

	Connection con; 
	public EmployeeDaoImpl()
	{
		con = DBUtil.getConnect();
	}
	@Override
	public int addEmployee(Employee bean) throws EmployeeException {
		// TODO Auto-generated method stub
		int id = 0;
		String sql = "INSERT INTO Employee VALUES(empId_seq.NEXTVAL,?,?)";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(sql);
			pstmt.setString(1, bean.getEmpName());
			pstmt.setInt(2, bean.getEmpSal());
			int row = pstmt.executeUpdate();
			if(row==1)
				id = getEmployeeId();
			else
				throw new EmployeeException("unable to insert");
			
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return id;
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM Employee";
		ArrayList<Employee>list = new ArrayList<Employee>();
		try
		{
			Statement stmt = 
					con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				Employee emp = new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmpSal(rs.getInt(3));
				list.add(emp);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException("No record found");
		}
		return list;
	}

	@Override
	public Employee getEmployeeById(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		Employee emp = null;
		String sql = 
				"SELECT * FROM Employee WHERE empId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(sql);
			pstmt.setInt(1,empId);
			ResultSet rs = 
					pstmt.executeQuery();
			if(rs.next())
			{
				emp = new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmpSal(rs.getInt(3));
			}
			else
				throw new EmployeeException("No found id"+empId);
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
			return emp;
		
	}
	public int getEmployeeId()throws EmployeeException
	{
		int id = 0;
		String sql = "SELECT empId_seq.CURRVAL FROM DUAL";
		try
		{
			Statement stmt =
					con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
			{
				id = rs.getInt(1);
			}
			
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return id;
	}
	public Employee updateEmployee(int empId,int empSal)throws EmployeeException
	{
		Employee emp = null;
		String sql =
				"UPDATE Employee SET empSal = ? WHERE empId = ?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(sql);
			pstmt.setInt(1, empSal);
			pstmt.setInt(2, empId);
			int row = pstmt.executeUpdate();
			if(row==1)
				emp = getEmployeeById(empId);
			else
				throw new EmployeeException("Unable to update");
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return emp;
	}
}


