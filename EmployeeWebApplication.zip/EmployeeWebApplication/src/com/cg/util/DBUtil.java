package com.cg.util;
import java.sql.*;

public class DBUtil {

	static Connection con;

	static
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "system";
			String pass = "poorvi";
			con = DriverManager.getConnection(url,user,pass);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static Connection getConnect()
	{
		return con;
	}
}
