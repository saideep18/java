package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      EmployeeService service =
    		  new EmployeeServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		String qStr = request.getParameter("action");
		if("add".equals(qStr))
		{
			RequestDispatcher dispatch =
					request.getRequestDispatcher("addEmp.jsp");
			dispatch.forward(request, response);
		}
		if("getAll".equals(qStr))
		{
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("allEmp.jsp");
			try {
				ArrayList<Employee>list = 
						service.getAllEmployee();
				session.setAttribute("empList", list);
				dispatch.forward(request, response);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				session.setAttribute("errorMsg", e.getMessage());
			}
			
			
		}
		if("getById".equals(qStr))
		{
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("acceptId.jsp");
			dispatch.forward(request, response);
		}
		if("update".equals(qStr))
		{
			int empId = 
					Integer.parseInt(request.getParameter("id"));
			session.setAttribute("empId", empId);
			RequestDispatcher dispatch =
					request.getRequestDispatcher("update.jsp");
			dispatch.forward(request, response);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(false);
		String qStr = request.getParameter("action");
		if("addEmp".equals(qStr))
		{
			String empName = request.getParameter("eName");
			int empSal = 
					Integer.parseInt(request.getParameter("eSal"));
			Employee bean = new Employee();
			bean.setEmpName(empName);
			bean.setEmpSal(empSal);
			try {
				int empId = service.addEmployee(bean);
				if(empId!=0)
				{
					session.setAttribute("empId", empId);
					RequestDispatcher dispatch =
							request.getRequestDispatcher("success.jsp");
					dispatch.forward(request, response);
				}
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				session.setAttribute("errorMsg", e.getMessage());
			}
		}
		if("showById".equals(qStr))
		{
			int empId = 
					Integer.parseInt(request.getParameter("empId"));
			Employee emp;
			try {
				emp = service.getEmployeeById(empId);
				if(emp!=null)
				{
					session.setAttribute("emp", emp);
					RequestDispatcher dispatch = 
							request.getRequestDispatcher("getEmp.jsp");
					dispatch.forward(request, response);
				}
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				session.setAttribute("errorMsg", e.getMessage());
			}
			
			
		}
		if("updateEmp".equals(qStr))
		{
			int empSal = 
					Integer.parseInt(request.getParameter("salary"));
			int empId = (Integer)session.getAttribute("empId");
			try{
				Employee emp = service.updateEmployee(empId, empSal);
			
			if(emp!=null)
			{
				session.setAttribute("updatedEmp", emp);
				RequestDispatcher dispatch = 
						request.getRequestDispatcher("showUpdate.jsp");
				dispatch.forward(request, response);
			}}
			catch(EmployeeException e)
			{
				session.setAttribute("errorMsg",e.getMessage());
			}
		}
	
	}

}
