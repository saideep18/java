import java.sql.*;

public class MainClass {
	 
	public static void main(String[] args) {
		
		
		//always provide try catch in main ...never use throws
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");  //forname() to load type 4 driver
			String url = "jdbc:oracle:thin:@localhost:1522:orcl";
			String username = "system";
			String passwd ="oracle";
			
			
			Connection con= DriverManager.getConnection(url,username,passwd);
		Statement stmt = con.createStatement();
		String sql="SELECT * FROM student";
		ResultSet rs= stmt.executeQuery(sql);  
		// executequery() returns the table and stores it in rs variable
		//the table is always pointed at the first variable
		while(rs.next())
		{
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
		}
		
		
		}
		catch ( ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}

}
