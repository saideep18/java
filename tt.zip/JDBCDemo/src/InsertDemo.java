import java.sql.*;
import java.time.LocalDate;
import java.time.Month;


public class InsertDemo {
	public static void main(String[] args) {
		
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1522:orcl";
		String pass = "oracle";
		String user = "system";
		Connection con =
		DriverManager.getConnection(url,user,pass);
		String sql = "INSERT INTO JeeEmp VALUES (empId_seq.NEXTVAL,?,?,?)";
		PreparedStatement pstmt = 
				con.prepareStatement(sql);
		pstmt.setString(1,"Rima");
		pstmt.setInt(2, 100000);
		LocalDate date = LocalDate.of(1988, Month.APRIL, 12);
		Date bDate = Date.valueOf(date);
		pstmt.setDate(3,bDate);
		int row = pstmt.executeUpdate();
		if (row==1)
		{
			System.out.println("inserted successfully");
		
		}}
	catch(Exception e){
	System.out.println(e.getMessage());	
	}
}
}