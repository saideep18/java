
import java.sql.*;



public class UpdateDemo {
	public static void main(String[] args) {
		
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1522:orcl";
		String pass = "oracle";
		String user = "system";
		Connection con =
		DriverManager.getConnection(url,user,pass);
		
		String sql = "update JeeEmp set empSal = empSal +1000 where empId = ?";
		PreparedStatement pstmt = 
				con.prepareStatement(sql);
		pstmt.setInt(1, 1000);
		int row1 = pstmt.executeUpdate();
		if (row1==1)
		{
			System.out.println("updated successfully");
		
}
		}
	catch(Exception e){
	System.out.println(e.getMessage());	
	}
}
}
