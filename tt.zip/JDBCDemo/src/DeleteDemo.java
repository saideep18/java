import java.sql.*;

public class DeleteDemo {
	public static void main(String[] args) {
		
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1522:orcl";
		String username = "system";
		String password = "oracle";
		
		Connection con =
		DriverManager.getConnection(url,username,password);
		
		String sql = "delete from JeeEmp WHERE empId = ?";
		PreparedStatement pstmt = 
				con.prepareStatement(sql);
		pstmt.setInt(1, 1000);
		int row1 = pstmt.executeUpdate();
		if (row1==1)
		{
			System.out.println("deleted successfully");
		
}
		}
	catch(Exception e){
	System.out.println(e.getMessage());	
	}
}
}
