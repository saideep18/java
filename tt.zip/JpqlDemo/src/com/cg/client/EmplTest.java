package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.entity.Empl;
import com.cg.util.DBUtil;

public class EmplTest {

	public static void main(String[] args) {
		
		EntityManager em=DBUtil.getManager();
		TypedQuery<Empl>query=
		em.createNamedQuery("getById", Empl.class);
		query.setParameter("eid", 104);
		Empl obj = query.getSingleResult();
		System.out.println("id="+ obj.getEmpId());
		System.out.println("name="+obj.getEmpName());
		System.out.println("salary="+obj.getEmpSal());
		
	}
}
