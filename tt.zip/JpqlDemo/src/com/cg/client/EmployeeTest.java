package com.cg.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.entity.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

public class EmployeeTest {

	public static void main(String[] args) {
		
     int choice=0;
     
     EmployeeService service= new EmployeeServiceImpl();
     Scanner sc=new Scanner(System.in);
     do
     {
    	 System.out.println("1-getEmployeebyId");
    	 System.out.println("2-getAllemployees");
    	 System.out.println("3-getEmployeeBySalary");
    	 System.out.println("enter your choice");
    	 choice =sc.nextInt();
    	 switch(choice) {
    	 
    	 case 1: System.out.println("Enter Id to search an Employee :");
    	          
    	           int eid= sc.nextInt();
    	           Employee emp=service.getEmployeeById(eid);
    	           System.out.println("emp name"+ emp.getEmpName());
    	           System.out.println("emp salary"+ emp.getEmpSal());
    	           break;
    	           
    	 case 2: ArrayList<Employee>list=
 				 service.getAllemployee();
    	 for(Employee emps : list) {
    		 System.out.println(emps.getEmpId());
    		 System.out.println(emps.getEmpName());
    		 System.out.println(emps.getEmpSal());
    		 System.out.println();
    		 
    	 }
    	     break;      
    	     
    	 case 3: System.out.println("enter salary of the employee :");
    	         int salary=sc.nextInt();
    	         ArrayList<Employee>list1=
    	 				 service.getEmployeeBySalary(salary);
    	         System.out.println("employees with salary greater than given salary");
    	         
    	         for(Employee emp1 : list1)
    	         {
    	        	 System.out.println(emp1.getEmpId());
    	    		 System.out.println(emp1.getEmpName());
    	    		 System.out.println(emp1.getEmpSal());
    	    		 System.out.println(); 
    	        	 
    	        	 
    	         }
    	         break;
    	     
    	 
    	 }
    	 System.out.println("do you want to continue 1-yes 2-no");
    	 choice=sc.nextInt();
    	 
     }while(choice!=0);
		
		
		
		
		
	}

	
}
