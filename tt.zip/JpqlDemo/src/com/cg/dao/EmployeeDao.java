package com.cg.dao;

import java.util.ArrayList;

import com.cg.entity.Employee;

public interface EmployeeDao {

	public Employee getEmployeeById(int id);
	public ArrayList<Employee>getAllemployee();
	public ArrayList<Employee> getEmployeeBySalary(int salary);
	
}
