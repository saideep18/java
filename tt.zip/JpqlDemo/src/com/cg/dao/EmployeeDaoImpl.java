package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.entity.Employee;
import com.cg.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	EntityManager em;
	
	public EmployeeDaoImpl() {
		em=DBUtil.getManager();
	}
	
	
	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		String sql="SELECT emp FROM Employee emp WHERE emp.empId=:eid";  //dynamic query
		//em.getTransaction().begin();
		Query query=em.createQuery(sql);
		query.setParameter("eid",id); //assigning dynamic query
		Employee obj= (Employee)query.getSingleResult();
		return obj;
	}

	@Override
	public ArrayList<Employee> getAllemployee() {
		// TODO Auto-generated method stub
		String sql="SELECT emp FROM Employee emp";
		//em.getTransaction().begin();
		TypedQuery<Employee>query =
				em.createQuery(sql, Employee.class);
		ArrayList<Employee>list=
				(ArrayList<Employee>) query.getResultList();
		return list;
		
	
	}

	@Override
	public ArrayList<Employee> getEmployeeBySalary(int salary) {
		// TODO Auto-generated method stub
		String sql="SELECT emp FROM Employee emp WHERE emp.empSal>:sal";
		TypedQuery<Employee>query=
				em.createQuery(sql, Employee.class);
		query.setParameter("sal", salary);
		ArrayList<Employee>list=
				(ArrayList<Employee>) query.getResultList();
		
		return list;
	}
	
	public void closeEntityManager() {
		em.close();
		
	}
	

}
