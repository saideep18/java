package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="EmpJEE")
@NamedQueries({
	@NamedQuery(name="getById",query="SELECT emp FROM Empl emp WHERE emp.empId=:eid")
	, @NamedQuery(name="getAllData",query="SELECT emp FROM Empl emp")
})
public class Empl implements Serializable{
	
	@Id
	int empId;
	String empName;
	int empSal;
	
	public Empl() {
		
	}
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	
	
	

}
