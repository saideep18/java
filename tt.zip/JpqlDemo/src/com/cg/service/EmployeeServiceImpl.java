package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;
import com.cg.entity.Employee;

public class EmployeeServiceImpl  implements EmployeeService{

	
	EmployeeDao dao;
	public EmployeeServiceImpl() {
		dao=new EmployeeDaoImpl();
	}
	
	
	
	
	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		return dao.getEmployeeById(id);
	}

	
	
	@Override
	public ArrayList<Employee> getAllemployee() {
		// TODO Auto-generated method stub
		return dao.getAllemployee();
	}

	@Override
	public ArrayList<Employee> getEmployeeBySalary(int salary) {
		// TODO Auto-generated method stub
		return dao.getEmployeeBySalary(salary);
	}

	
	
	
}
