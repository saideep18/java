package com.cg.service;

import java.util.ArrayList;

import com.cg.entity.Employee;

public interface EmployeeService {

	public Employee getEmployeeById(int eid);
	public ArrayList<Employee>getAllemployee();
	public ArrayList<Employee> getEmployeeBySalary(int salary);
	
	
}
