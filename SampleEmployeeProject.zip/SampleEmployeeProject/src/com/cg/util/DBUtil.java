package com.cg.util;

import java.util.HashMap;

import com.cg.bean.Employee;

public class DBUtil {
	
	static int id = 0;
	static HashMap<Integer,Employee>map
	= new HashMap<Integer,Employee>();
	
	static
	{
		map.put(++id, new Employee(id,"Rima",20000));
		map.put(++id, new Employee(id,"Raj",30000));
		map.put(++id, new Employee(id,"Priya",30000));
		map.put(++id, new Employee(id,"Hari",10000));
		map.put(++id, new Employee(id,"kriti",20000));
	}
	public static HashMap<Integer,Employee> getEmployees()
	{
		return map;
	}
}
