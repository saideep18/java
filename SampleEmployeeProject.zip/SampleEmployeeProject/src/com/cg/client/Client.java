package com.cg.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeService service = new EmployeeServiceImpl();
		int choice = 0;
		try(Scanner sc = new Scanner(System.in))
		{
			do
			{
				System.out.println("1-Show All Employees");
				System.out.println("2-Delete Employee");
				System.out.println("3-Serach Employee");
				System.out.println("4-update Employee");
				System.out.println("Enter your choice::");
				choice = sc.nextInt();
				switch(choice)
				{
				case 1 : try {
						ArrayList<Employee>list =
									service.getAllEmployees();
						for(Employee emp : list)
						{
							System.out.println(emp);
						}
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				break;
				case 2: 
					System.out.println("Enter id to delete an Employee::");
					int id = sc.nextInt();
					try {
						ArrayList<Employee>list = 
						service.deleteEmployee(id);
						System.out.println("After deletion::");
						for(Employee emp : list)
						{
							System.out.println(emp);
						}
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					break;
				case 3: 
					System.out.println("Enter id to search an Employee::");
					int eid = sc.nextInt();
					try {
						Employee emp = 
								service.searchEmployee(eid);
						System.out.println(emp);
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					break;	
				
				case 4 : System.out.println("Enter id to update salary of an Employee::");
							int empId = sc.nextInt();
							System.out.println("Enter new Salary::");
							int sal = sc.nextInt();
							try{
							Employee emp = service.updateEmployee(empId,sal);
							System.out.println("After update" +emp);
							}
							catch(EmployeeException e)
							{
								System.out.println(e.getMessage());
							}
				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();
			}
			while(choice!=0);
		}
		
	}

}
