package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{

	static HashMap<Integer,Employee>map;
	
	public EmployeeDaoImpl()
	{
		map = DBUtil.getEmployees();
	}
	@Override
	public ArrayList<Employee> getAllEmployees()throws EmployeeException {
		// TODO Auto-generated method stub
		ArrayList<Employee>list = null;
		if(map.size()!=0)
		{
			list = new ArrayList<Employee>();
			Set<Integer> keys = map.keySet();
			for(Integer key : keys)
			{
				Employee obj = map.get(key);
				list.add(obj);
			}
		}
		else
			throw new EmployeeException("No data Found");
		return list;
	}

	@Override
	public ArrayList<Employee> deleteEmployee(int id) throws EmployeeException{
		// TODO Auto-generated method stub
		ArrayList<Employee>list = null;
		if(map.size()!=0)
		{
			Employee ref = map.remove(id);
			if(ref==null)
				throw new EmployeeException("id "+id +"does not exist");
			else if(map.size()!=0)
			{
				list = new ArrayList<Employee>();
				Set <Integer>keys = map.keySet();
				for(Integer key : keys)
				{
					Employee obj = map.get(key);
					list.add(obj);
				}
				
			}
		}
		else
			throw new EmployeeException("No Data Found");
		return list;
	}

	@Override
	public Employee updateEmployee(int id,int sal) throws EmployeeException{
		// TODO Auto-generated method stub
		Employee emp = map.get(id);
		if(emp==null)
			throw new EmployeeException("id "+id+" does not exist");
		else{
			emp.setEmpSal(sal);
			map.put(emp.getEmpId(), emp);
		}
		return emp;
	}

	@Override
	public Employee searchEmployee(int id)throws EmployeeException {
		// TODO Auto-generated method stub
		Employee emp = null;
		if(map.size()!=0)
		{
			 emp = map.get(id);
		}
		else
			throw new EmployeeException("No Data Found");
		return emp;
	}

}
