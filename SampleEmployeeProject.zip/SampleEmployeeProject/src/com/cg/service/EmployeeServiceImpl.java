package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;
import com.cg.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao = new EmployeeDaoImpl();
	@Override
	public ArrayList<Employee> getAllEmployees()throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getAllEmployees();
	}

	@Override
	public ArrayList<Employee> deleteEmployee(int id) throws EmployeeException{
		// TODO Auto-generated method stub
		return dao.deleteEmployee(id);
	}

	@Override
	public Employee updateEmployee(int id,int sal) throws EmployeeException{
		// TODO Auto-generated method stub
		return dao.updateEmployee(id,sal);
	}

	@Override
	public Employee searchEmployee(int id) throws EmployeeException{
		// TODO Auto-generated method stub
		return dao.searchEmployee(id);
	}
	
	

}
