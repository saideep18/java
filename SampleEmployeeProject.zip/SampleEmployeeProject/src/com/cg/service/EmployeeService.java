package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;

public interface EmployeeService {

	public ArrayList<Employee> getAllEmployees()throws EmployeeException;
	public ArrayList<Employee> deleteEmployee(int id)throws EmployeeException;
	public Employee updateEmployee(int id,int sal)throws EmployeeException;
	public Employee searchEmployee(int id)throws EmployeeException;
	
}
