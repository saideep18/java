package com.spring.mvc.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.mvc.model.Employee;



@Controller
public class LoginController {

	@RequestMapping("/home")
	public String showHomePage() {
		String view="home";
		return view;
		
	}
	
	@RequestMapping("/login")
	public String showLoginPage() {
		
		String view="login";
		return view;
		
	}
	
	@RequestMapping(value="/checkLogin", method=RequestMethod.POST)
	public String checkLoginDetails(Model model,@RequestParam("uname") String name,@RequestParam("pword") String pass) {
		
		String view=" ";
		if("admin".equalsIgnoreCase(name) && "admin".equals(pass)) {
			view ="success";
			model.addAttribute("msg", "login success "+name);
			
			}else {
				view="error";
				model.addAttribute("error","login failed...");
			}
		return view;
		
	}
	
	
	
	
	@RequestMapping("/register")
	public String showRegisterPage(Model model) {
		
		String view="register";
		model.addAttribute("employee",new Employee());
		
		List<String> list=new ArrayList<>();
		list.add("Hyderabad");
		list.add("Mumbai");
		list.add("Chennai");
		list.add("Banglore");
		
		model.addAttribute("cities",list);
		
		return view;
		
	}
	
	@RequestMapping(value="/register", method = RequestMethod.POST)
	public String processRegistration(@ModelAttribute("employee") Employee employee , Model model) {
		String view="registerSuccess";
		model.addAttribute("emp",employee);
		return view;
		
		
	}
	
	
}
